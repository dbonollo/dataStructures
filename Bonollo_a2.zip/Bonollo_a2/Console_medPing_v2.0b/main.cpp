#include "stdafx.h"
#include "mp_InputOutput.h"
#include "medPing.h"

//================================================================
// Programmer: Destiny Bonollo
//
// Summary: 
//
// Modification History:
//    12/15/08 -- (mdl) medPing lives ...
//	  02/28/14 -- (dbb) program 2
//
//================================================================


int main (int argc, char * const argv[])
{
	medPing_Main();
	
	system("PAUSE");
	return 0;
}
