Programmer: Destiny Bonollo

This program focuses on handling quadratic or linear equations to find Real roots and print those values.

Files:
README.txt: the file you are currently reading
a0.cpp: the source code, made on Visual Studio

Date last modified: January 31, 2014
Program Progress: tested (many, many times) and in running condition